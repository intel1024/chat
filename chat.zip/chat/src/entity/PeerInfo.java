package entity;

import java.io.Serializable;

public class PeerInfo implements Serializable {
private String localIp;
private int localPort;
private int uid;
public String getLocalIp() {
	return localIp;
}
public void setLocalIp(String localIp) {
	this.localIp = localIp;
}
public int getLocalPort() {
	return localPort;
}
public void setLocalPort(int localPort) {
	this.localPort = localPort;
}
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}

}
