package entity;

import java.io.Serializable;

public class ChatInfo implements Serializable {
private int senderId;
private int receiverId;
private String sentTime;
private String content;
public int getSenderId() {
	return senderId;
}
public void setSenderId(int senderId) {
	this.senderId = senderId;
}
public int getReceiverId() {
	return receiverId;
}
public void setReceiverId(int receiverId) {
	this.receiverId = receiverId;
}
public String getSentTime() {
	return sentTime;
}
public void setSentTime(String sentTime) {
	this.sentTime = sentTime;
}
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
@Override
public String toString() {
	return "ChatInfo [senderId=" + senderId + ", receiverId=" + receiverId
			+ ", sentTime=" + sentTime + ", content=" + content + "]";
}

}
