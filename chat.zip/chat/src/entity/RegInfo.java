package entity;

import java.io.Serializable;

public class RegInfo implements Serializable {
private String uname;
private int age;
private String email;
private String pass;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
@Override
public String toString() {
	return "RegInfo [uname=" + uname + ", age=" + age + ", email=" + email
			+ ", pass=" + pass + "]";
}

}
