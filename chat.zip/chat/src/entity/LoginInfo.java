package entity;

import java.io.Serializable;

public class LoginInfo implements Serializable {
private int uid;
private String pass;
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}

}
