package entity;

import java.io.Serializable;

public class NotifyObject implements Serializable {
public static final int TEST_CHAT = 1;
private int notifyType;
private Object notifyBody;
private String srcIP;
private int srcPort;
private String destIP;
private int destPort;
public int getNotifyType() {
	return notifyType;
}
public void setNotifyType(int notifyType) {
	this.notifyType = notifyType;
}
public Object getNotifyBody() {
	return notifyBody;
}
public void setNotifyBody(Object notifyBody) {
	this.notifyBody = notifyBody;
}
public String getSrcIP() {
	return srcIP;
}
public void setSrcIP(String srcIP) {
	this.srcIP = srcIP;
}
public int getSrcPort() {
	return srcPort;
}
public void setSrcPort(int srcPort) {
	this.srcPort = srcPort;
}
public String getDestIP() {
	return destIP;
}
public void setDestIP(String destIP) {
	this.destIP = destIP;
}
public int getDestPort() {
	return destPort;
}
public void setDestPort(int destPort) {
	this.destPort = destPort;
}

}
