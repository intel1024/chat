package entity;

import java.io.Serializable;

public class RequestObject implements Serializable {
public static final int TEST_REQ = 999;
public static final int TEST_REQ2=998;
public static final int REG_REQ = 1;
public static final int INIT_ALL = 2;
public static final int LOGIN_REQ = 3;
public static final int LOGOFF_REQ = 4;
public static final int OFF_MSG = 5;
public static final int FETCH_MSG = 6;
public static final int PEER_REG = 7;
private int reqType;
private Object reqBody;
public int getReqType() {
	return reqType;
}
public void setReqType(int reqType) {
	this.reqType = reqType;
}
public Object getReqBody() {
	return reqBody;
}
public void setReqBody(Object reqBody) {
	this.reqBody = reqBody;
}
public RequestObject(int reqType, Object reqBody) {
	super();
	this.reqType = reqType;
	this.reqBody = reqBody;
}

}
