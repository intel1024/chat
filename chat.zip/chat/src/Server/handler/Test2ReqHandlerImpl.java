package Server.handler;

import entity.RequestObject;
import entity.ResponseObject;

public class Test2ReqHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		System.out.println(requestObject.getReqBody());
		responseObject=new ResponseObject(ResponseObject.TEST_RES2, "RES 2");
		return responseObject;
	}

}
