package Server.handler;

import java.sql.ResultSet;
import java.util.Vector;

import Server.helper.DBAccessHelper;

import entity.ChatInfo;
import entity.RequestObject;
import entity.ResponseObject;

public class FetchMsgReqHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		try {
			String uidStr=(String)requestObject.getReqBody();
			String sqlString="select senderid,receiverid,senttime,content from chatstore where receiverid="+uidStr;
			System.out.println(sqlString);
			ResultSet rs=DBAccessHelper.getInstannce().executeQuery(sqlString);
			Vector<ChatInfo> allChats=new Vector<ChatInfo>();
			ChatInfo chatInfo;
			while(rs.next()){
				chatInfo=new ChatInfo();
				chatInfo.setSenderId(rs.getInt(1));
				chatInfo.setReceiverId(rs.getInt(2));
				chatInfo.setSentTime(rs.getString(3));
				chatInfo.setContent(rs.getString(4));
				allChats.addElement(chatInfo);
				System.out.println(chatInfo);
			}
			sqlString="delete from chatstore where receiverid="+uidStr;
			DBAccessHelper.getInstannce().execute(sqlString);
			responseObject=new ResponseObject(ResponseObject.FETCH_RES, allChats);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return responseObject;
	}

}
