package Server.handler;

import java.sql.ResultSet;

import Server.helper.DBAccessHelper;

import entity.LoginInfo;
import entity.RequestObject;
import entity.ResponseObject;

public class LoginReqHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		try {
			LoginInfo loginInfo=
					(LoginInfo)requestObject.getReqBody();
			int uid=loginInfo.getUid();
			String pass=loginInfo.getPass();
			String sqlString=
					"select count(0) from contacts where uid="+uid+" and pass='"+pass+"'";
			System.out.println();
			ResultSet rs=DBAccessHelper.getInstannce().executeQuery(sqlString);
			int count=0;
			if(rs.next()){
				count=rs.getInt(1);
			}
			if(count==0){
				responseObject=
						new ResponseObject(ResponseObject.LOGIN_FAIL, "Password/UID doesn't match!!!!Check or Register!");
			}else{
				responseObject=
						new ResponseObject(ResponseObject.REG_SUCCESS, null);
				String sqlString2="update contacts set online =1 where uid="+uid+"";
				System.out.println(sqlString2);
				DBAccessHelper.getInstannce().execute(sqlString2);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return responseObject;
	}

}
