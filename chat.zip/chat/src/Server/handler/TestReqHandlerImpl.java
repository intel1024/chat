package Server.handler;

import entity.RequestObject;
import entity.ResponseObject;

public class TestReqHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		System.out.println(requestObject.getReqBody());
		responseObject=new ResponseObject(ResponseObject.TEST_RES1, "RES 1");
		return responseObject;
	}

}
