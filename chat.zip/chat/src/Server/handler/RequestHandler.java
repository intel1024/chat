package Server.handler;

import entity.RequestObject;
import entity.ResponseObject;

public interface RequestHandler {
public ResponseObject handleRequest(RequestObject requestObject);
}
