package Server.handler;

import Server.helper.DBAccessHelper;
import entity.PeerInfo;
import entity.RequestObject;
import entity.ResponseObject;

public class PeerReqHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		try {
			PeerInfo peerInfo;
			peerInfo=(PeerInfo)requestObject.getReqBody();
			int uid=peerInfo.getUid();
			String localip=peerInfo.getLocalIp();
			int localport=peerInfo.getLocalPort();
			String sqlString="update contacts set localip='"+localip+"',localport="+localport+" where uid="+uid;
			System.out.println(sqlString);
			DBAccessHelper.getInstannce().execute(sqlString);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return responseObject;
	}

}
