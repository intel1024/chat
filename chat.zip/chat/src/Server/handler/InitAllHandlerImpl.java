package Server.handler;

import java.sql.ResultSet;
import java.util.Vector;

import Server.helper.DBAccessHelper;

import entity.Contact;
import entity.RequestObject;
import entity.ResponseObject;

public class InitAllHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		try {
			//1.query db
			String sqlString=
					"select uid,uname,age,email,online,localIP,localPort "+" from contacts";
			ResultSet rs=
					DBAccessHelper.getInstannce().executeQuery(sqlString);
			//2.process rs
			Contact contact;
			Vector<Contact> allContacts=
					new Vector<Contact>();
			while(rs.next()){
				contact=new Contact();
				contact.setUid(rs.getInt(1));
				contact.setUname(rs.getString(2));
				contact.setAge(rs.getInt(3));
				contact.setEmail(rs.getString("email"));
				if(rs.getInt(5)==0){
					contact.setOnline(false);
				}
				else{
					contact.setOnline(true);
				}
				contact.setLocalIP(rs.getString("localip"));
				contact.setLocalPort(rs.getInt("localPort"));
				System.out.println(contact);
				allContacts.addElement(contact);
			}
			responseObject=
					new ResponseObject(ResponseObject.INIT_ALL_RES, allContacts);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return responseObject;
	}

}
