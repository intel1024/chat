package Server.handler;

import Server.helper.DBAccessHelper;
import entity.ChatInfo;
import entity.RequestObject;
import entity.ResponseObject;

public class OffChatReqHandlerImpl implements RequestHandler {

	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		try {
			ChatInfo chatInfo=(ChatInfo)requestObject.getReqBody();
			int senderid=chatInfo.getSenderId();
			int receiverid=chatInfo.getReceiverId();
			String senttime=chatInfo.getSentTime();
			String content=chatInfo.getContent();
			String sqlString="insert into chatstore"+
			" (senderid,receiverid,senttime,content)"+
			" values("+senderid+","+receiverid+",'"+senttime+"','"+content+"')";
			System.out.println(sqlString);
			
			DBAccessHelper.getInstannce().execute(sqlString);
			responseObject=new ResponseObject(ResponseObject.OFF_CHAT_RES, null);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return responseObject;
	}

}
