package Server.handler;

import java.sql.ResultSet;

import org.omg.CORBA.INTERNAL;

import Server.helper.DBAccessHelper;


import entity.RegInfo;
import entity.RequestObject;
import entity.ResponseObject;

public class RegReqHandlerImpl implements RequestHandler {


	@Override
	public ResponseObject handleRequest(RequestObject requestObject) {
		// TODO Auto-generated method stub
		ResponseObject responseObject=null;
		try {
			RegInfo regInfo=(RegInfo)requestObject.getReqBody();
			System.out.println(regInfo);
			String uname=regInfo .getUname();
			int age=regInfo.getAge();
			String email=regInfo.getEmail();
			String pass=regInfo.getPass();
			boolean isValid=validateEmail(email);
			if(!isValid){
				responseObject=
						new ResponseObject(ResponseObject.REG_FAIL, "Email Duplicated!Try Again!");
				return responseObject;
			}
			
			int newUID=assignUID();
			insertNew(newUID,uname,email,pass,age);
			responseObject=new ResponseObject(ResponseObject.REG_SUCCESS, ""+newUID);
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return responseObject;
	}

	private void insertNew(int newUID, String uname, String email, String pass, int age) {
		// TODO Auto-generated method stub
		try {
			String sqlString=
					"insert into Contacts "
					+" (uid,uname,email,age,pass)"
					+" values("+newUID+",'"+uname+"','"+email+"',"+age+",'"+pass+"')";
			System.out.println(sqlString);
			DBAccessHelper.getInstannce().execute(sqlString);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private int assignUID() {
		// TODO Auto-generated method stub
		int UID=10000;
		try {
			String sqlString=
					"select max(uid) from contacts";
			ResultSet rs=
					DBAccessHelper.getInstannce().executeQuery(sqlString);
			if(rs!=null){
				if(rs.next()){
					UID=rs.getInt(1);
					System.out.println("maxUID:"+UID);
					//CAUTION BUG
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return ++UID;
	}

	private boolean validateEmail(String email) {
		// TODO Auto-generated method stub
		boolean result=false;
		try {
			String sqlString=
					"select count(0) from contacts"+
			" where email='"+email+"'";
			ResultSet rs=
					DBAccessHelper.getInstannce().executeQuery(sqlString);
			int count;
			if(rs.next()){
				count=rs.getInt(1);
				if(count==0)result=true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return result;
	}

}
