package Server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import test.TestEntity;

public class ChatServer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		ServerSocket chatServer=new ServerSocket(10086);
		System.out.println("Blues Chat Server is Running.....");
		//for(;;)
		Socket clientSocket;
		WorkerThread worker;
		while(true){
		clientSocket=chatServer.accept();
		//System.out.println("Request accepted.....");
		
		//tmpStr=(String)ois.readObject();
		worker=new WorkerThread(clientSocket);
		worker.start();
		}	
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
