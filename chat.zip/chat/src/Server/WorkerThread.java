package Server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;


import entity.RequestObject;
import entity.ResponseObject;

import Server.handler.FetchMsgReqHandlerImpl;
import Server.handler.InitAllHandlerImpl;
import Server.handler.LoginReqHandlerImpl;
import Server.handler.LogoffReqHandlerImpl;
import Server.handler.OffChatReqHandlerImpl;
import Server.handler.PeerReqHandlerImpl;
import Server.handler.RegReqHandlerImpl;
import Server.handler.RequestHandler;
import Server.handler.Test2ReqHandlerImpl;
import Server.handler.TestReqHandlerImpl;
import test.TestEntity;

public class WorkerThread extends Thread {
private Socket clientSocket;
private RequestHandler handler;

public WorkerThread(Socket clientsSocket) {
	super();
	this.clientSocket = clientsSocket;
}
public void run(){
	try {
		ObjectInputStream ois=
				new ObjectInputStream(clientSocket.getInputStream());;
		//String tmpStr;
		RequestObject requestObject;
		//TestEntity testObj;
		requestObject=(RequestObject)ois.readObject();
		switch (requestObject.getReqType()) {
		case RequestObject.TEST_REQ:
//			System.out.println("TEST REQ 1");
			handler=new TestReqHandlerImpl();
			break;
        case RequestObject.TEST_REQ2:
        	handler=new Test2ReqHandlerImpl();
//			System.out.println("TEST REQ 2");
			break;
        case RequestObject.REG_REQ:
        	handler=new RegReqHandlerImpl();
//			System.out.println("REG REQ 1");
			break;
        case RequestObject.INIT_ALL:
        	handler=new InitAllHandlerImpl();
//			System.out.println("Init All 1");
			break;
        case RequestObject.LOGIN_REQ:
        	handler=new LoginReqHandlerImpl();
//			System.out.println("Login Req 1");
			break;
        case RequestObject.LOGOFF_REQ:
        	handler=new LogoffReqHandlerImpl();
//			System.out.println("Login Off 1");
			break;
        case RequestObject.OFF_MSG:
        	handler=new OffChatReqHandlerImpl();
//			System.out.println("Off Chat 1");
			break;
        case RequestObject.FETCH_MSG:
        	handler=new FetchMsgReqHandlerImpl();
//			System.out.println("Fetch Msg 1");
			break;
        case RequestObject.PEER_REG:
        	handler=new PeerReqHandlerImpl();
//			System.out.println("Fetch Msg 1");
			break;

		default:
			break;
		}
		ResponseObject responseObject;
		responseObject=handler.handleRequest(requestObject);
		ObjectOutputStream oos=
				new ObjectOutputStream(clientSocket.getOutputStream());;
		//System.out.println("tmpStr is:"+requestObject);
		oos.writeObject(responseObject);
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	
}
}
