package Server.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBAccessHelper {
private	static DBAccessHelper dao;
	private DBAccessHelper() {
		// TODO Auto-generated constructor stub
		try {
			Class
			.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static DBAccessHelper getInstannce(){
		if(dao==null)dao=new DBAccessHelper();
		return dao;
	}
	public void execute(String sqlString){
		try {
			//2.��ȡ����
			String url="jdbc:mysql://localhost:3306/sschatdb";
			String user="root";
			String password="123456";
			Connection conn=DriverManager
					.getConnection(url, user, password);
			//3.׼�����
			System.out.println("DBAccessHelper execute:"+sqlString);
			PreparedStatement stmt=
			conn.prepareStatement(sqlString);
			stmt.execute();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	public ResultSet executeQuery(String sqlString){
		ResultSet rs=null;
		try {
			//2.��ȡ����
			String url="jdbc:mysql://localhost:3306/sschatdb";
			String user="root";
			String password="123456";
			Connection conn=DriverManager
					.getConnection(url, user, password);
			//3.׼�����
			System.out.println("DBAccessHelper execute:"+sqlString);
			PreparedStatement stmt=
			conn.prepareStatement(sqlString);
			rs=stmt.executeQuery();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return rs;
	}
}
