package client.helper;

import java.util.Hashtable;

public class SysRegistry {
private Hashtable<String, Object> sysReg;
private static SysRegistry instance;
private SysRegistry(){
	sysReg=new Hashtable<String, Object>();
	
}
public static SysRegistry getInstance(){
	if(instance==null)
		instance=new SysRegistry();
	return instance;
}
public void put(String key,Object value){
	sysReg.put(key, value);
}
public Object get(String key){
	return sysReg.get(key);
}
}
