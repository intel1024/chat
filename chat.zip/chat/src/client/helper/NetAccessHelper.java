package client.helper;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import test.TestEntity;
import entity.NotifyObject;
import entity.RequestObject;
import entity.ResponseObject;

public class NetAccessHelper {
public static ResponseObject sendRequest(RequestObject reqObj){
ResponseObject resObj=null;
try {
	Socket socket=new Socket("127.0.0.1",10086);
	ObjectOutputStream oos=
			new ObjectOutputStream(socket.getOutputStream());
    //TestEntity testObject=new TestEntity();	
    //testObject.setId(12345);
    //testObject.setName("test");
    oos.writeObject(reqObj);
//	oos.writeObject("Hello Blues");
	ObjectInputStream ois=
			new ObjectInputStream(socket.getInputStream());
	resObj=(ResponseObject)ois.readObject();
	//System.out.println(resObj);
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
return resObj;
}
public static void notify(NotifyObject notifyObject){
try {
	Socket socket=new Socket(notifyObject.getDestIP(),notifyObject.getDestPort());
	ObjectOutputStream oos=
			new ObjectOutputStream(socket.getOutputStream());
    oos.writeObject(notifyObject);
	
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
}
}