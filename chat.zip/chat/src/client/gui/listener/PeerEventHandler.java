package client.gui.listener;

import entity.NotifyObject;

public interface PeerEventHandler {
public void handleEvent(NotifyObject notifyObject);
}
