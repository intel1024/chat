package client.gui.listener;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class ClientListener extends Thread {
private String localIp;
private int localPort;
private ServerSocket listener;
	public void run(){
		try {
			listener=new ServerSocket(0);
			localPort=listener.getLocalPort();
			//attain effective ip
			//Inetddress.getLocalHost
			//listener.getInetAddress
			String ipStr=InetAddress.getLocalHost().toString();
			int idx=ipStr.indexOf('/');
			localIp=ipStr.substring(idx+1);
			System.out.println(localIp);
			Socket peer;
			ClientWorkerThread worker;
			while(true){
				peer=listener.accept();
				worker=new ClientWorkerThread(peer);
				worker.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getLocalIp() {
		return localIp;
	}
	public int getLocalPort() {
		return localPort;
	}
	public static void main(String[] args){
		ClientListener clientListener=new ClientListener();
		clientListener.start();
	}

}
