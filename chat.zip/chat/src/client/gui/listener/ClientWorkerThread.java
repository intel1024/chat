package client.gui.listener;

import java.io.ObjectInputStream;
import java.net.Socket;

import entity.NotifyObject;

public class ClientWorkerThread extends Thread {
private Socket peer;
private PeerEventHandler handler;
public ClientWorkerThread(Socket peer) {
	super();
	this.peer = peer;
}
public void run(){
	try {
		ObjectInputStream ois=new ObjectInputStream(peer.getInputStream());
		NotifyObject notifyObject=(NotifyObject)ois.readObject();
		System.out.println("***"+notifyObject.getNotifyBody());
		
		switch (notifyObject.getNotifyType()) {
		case NotifyObject.TEST_CHAT:
			handler=new TextChatHandlerImpl();
			break;

		default:
			break;
		}
		handler.handleEvent(notifyObject);
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
}

}
