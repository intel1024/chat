package client.gui.listener;

import java.util.Hashtable;

import javax.swing.DefaultListModel;

import client.gui.ChatBox;
import client.helper.SysRegistry;

import entity.ChatInfo;
import entity.Contact;
import entity.NotifyObject;

public class TextChatHandlerImpl implements PeerEventHandler {

	@Override
	public void handleEvent(NotifyObject notifyObject) {
		// TODO Auto-generated method stub
		try {
			ChatInfo chatInfo=(ChatInfo)notifyObject.getNotifyBody();
			//1.setsender
			//int senderId=chatInfo.getSenderId();
			//Contact senderContact;
			DefaultListModel contactsModel=(DefaultListModel)SysRegistry.getInstance().get("contactsModel");
			Hashtable< Contact, ChatBox> boxRegistry=(Hashtable<Contact, ChatBox>)SysRegistry.getInstance().get("boxRegistry");
			Contact bfContact=(Contact)SysRegistry.getInstance().get("currContact");
			int senderId=chatInfo.getSenderId();
			Contact senderContact,tmpContact;
			tmpContact=new Contact();
			tmpContact.setUid(senderId);
			int index=contactsModel.indexOf(tmpContact);
			senderContact=(Contact)contactsModel.elementAt(index);
			ChatBox chatBox=boxRegistry.get(senderContact);
			if(chatBox==null){
				chatBox=new ChatBox(bfContact, senderContact);
				boxRegistry.put(senderContact, chatBox);
			}
			if(!chatBox.isVisible()){
				senderContact.setSender(true);
			}
			//2.append msg
			String msg=chatInfo.getSentTime()+"\n"
					+senderContact.getUname()+" said:\n"
							+chatInfo.getContent()+"\n";
			chatBox.appendMsg(msg);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
