package client.gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import entity.Contact;

public class ContactsListCellRenderer implements ListCellRenderer {

	@Override
	public Component getListCellRendererComponent(JList list, Object value,
			int index, boolean isSelected, boolean cellHasFocus) {
		// TODO Auto-generated method stub
		ImageIcon onIcon=new ImageIcon("images/online.jpg");
		ImageIcon offIcon=new ImageIcon("images/offline.jpg");
		JLabel cellComp=
				new JLabel();
		if(value instanceof Contact){
		Contact contact=(Contact)value;
		if(contact.isOnline()){
			cellComp.setForeground(Color.GREEN);
			cellComp.setIcon(onIcon);
		}
		else {
			cellComp.setForeground(Color.RED);
			cellComp.setIcon(offIcon);
		}
		cellComp.setBackground(list.getBackground());
		if(isSelected){
			cellComp.setForeground(list.getSelectionForeground());
			cellComp.setBackground(list.getSelectionBackground());
		}
		String cellText="<"+contact.getUid()+">"+contact.getUname();
		if(contact.isSender()){
			cellComp.setForeground(Color.BLUE);
			cellText+="<incoming message...>";
		}
		cellComp.setText(cellText);
	}
		cellComp.setFont(list.getFont());
		cellComp.setOpaque(true);
		return cellComp;
	}

}
