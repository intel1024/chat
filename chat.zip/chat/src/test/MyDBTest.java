package test;

import java.security.interfaces.RSAKey;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MyDBTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//1.װ��Driver��
			Class
			.forName("com.mysql.jdbc.Driver");
			//2.��ȡ����
			String url="jdbc:mysql://localhost:3306/sschatdb";
			String user="root";
			String password="123456";
			Connection conn=DriverManager
					.getConnection(url, user, password);
			//3.׼�����
//			String sqlString=
//				"insert into Contacts "
//				+"(uid,uname,email,age,pass)"
//				+" values(20001,'bboboob','dadafa',32,'hello')";
//			System.out.println(sqlString);
//			PreparedStatement stmt=
//			conn.prepareStatement(sqlString);
//			stmt.execute();
			String sqlString2=
					"select uid,uname,email,age,online "
					+" from contacts ";
			System.out.println(sqlString2);
			PreparedStatement stmt=
			conn.prepareStatement(sqlString2);
			

			//4.ִ��
			ResultSet rs=stmt.executeQuery();

			//5.�����QUERY���������
			while(rs.next()){
				System.out.print("uid:"+rs.getInt(1));
				System.out.print("uname:"+rs.getString(2));
				System.out.print("email:"+rs.getString(3));
				System.out.print("age:"+rs.getShort(4));
				System.out.println("online:"+rs.getString(5));
			}
			//�ƶ��α�
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
