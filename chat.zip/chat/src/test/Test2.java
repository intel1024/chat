package test;

import java.sql.ResultSet;
import java.sql.SQLException;

import Server.helper.DBAccessHelper;


public class Test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String sqlString=
//		"insert into Contacts "
//		+"(uid,uname,email,age,pass)"
//		+" values(20002,'bboboob','dadafa',32,'hello')";
//		DBAccessHelper
//		.getInstannce()
//		.execute(sqlString);
		String sqlString2=
				"select uid,uname,email,age,online "
				+" from contacts ";
		ResultSet rs=
				DBAccessHelper.getInstannce().executeQuery(sqlString2);
		try {
			while(rs.next()){
				System.out.print("uid:"+rs.getInt(1));
				System.out.print("uname:"+rs.getString(2));
				System.out.print("email:"+rs.getString(3));
				System.out.print("age:"+rs.getShort(4));
				System.out.println("online:"+rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
