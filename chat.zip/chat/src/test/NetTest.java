package test;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import client.helper.NetAccessHelper;

import entity.RequestObject;
import entity.ResponseObject;

public class NetTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	try {
		//Socket server=new Socket("127.0.0.1",10086);
		//ObjectOutputStream oos=
	//			new ObjectOutputStream(server.getOutputStream());
        TestEntity testObject=new TestEntity();	
        testObject.setId(12345);
        testObject.setName("test");
        RequestObject requestObject=new RequestObject(RequestObject.TEST_REQ,"hello blues");
        ResponseObject responseObject=
        		NetAccessHelper.sendRequest(requestObject);
      //  oos.writeObject(testObject);
//		oos.writeObject("Hello Blues");
		//ObjectInputStream ois=
		//		new ObjectInputStream(server.getInputStream());
		//String tmpStr=(String)ois.readObject();
		System.out.println(responseObject.getResBody());
//		ObjectInputStream ois=
	//			new ObjectInputStream(server.getInputStream());
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}	
	}

}
